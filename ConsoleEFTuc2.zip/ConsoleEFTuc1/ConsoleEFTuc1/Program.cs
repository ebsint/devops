﻿using ConsoleEFTuc1;
using Microsoft.EntityFrameworkCore;

MyDbContext Context = new MyDbContext();

//Role Role1 = new Role();
//Role1.Name = "AssetCreator"; // Kan lägga in ny Asset i database.
//Role Role2 = new Role();
//Role2.Name = "Admin"; // Kan göra allt.

//Context.Roles.Add(Role1);
//Context.Roles.Add(Role2);
//Context.SaveChanges();

Console.WriteLine("ASSET MANAGER");

bool KeepRunning = true;

while (KeepRunning)
{
    Console.WriteLine("Choose an option:");
    Console.WriteLine("1. Log in");
    Console.WriteLine("2. Create an asset");
    Console.WriteLine("3. Log out");
    Console.WriteLine("Press q to exit");

    Console.Write("Make a choice: ");
    string UserChoice = Console.ReadLine();

    if(UserChoice == "1")
    {
        Console.Write("Username: ");
        string Username = Console.ReadLine();
        Console.Write("Password: ");
        string Password = Console.ReadLine();
        User UserForAuthentication = Context.Users.FirstOrDefault(
            x => x.Username == Username);
        if(UserForAuthentication.Password == Password)
        {
            UserForAuthentication.Loggedin = "yes";
            Context.Users.Update(UserForAuthentication);
            Context.SaveChanges();
        }
    }
    else if (UserChoice == "2")
    {
        User LoggedInUser = Context.Users.Include(x => x.Roles)
            .FirstOrDefault(
            x => x.Loggedin == "yes");
        if(LoggedInUser != null)
        {

            List<Role> UserRoles = LoggedInUser.Roles;
            Role Role1 = UserRoles.FirstOrDefault(x => x.Name == "AssetCreator");
            Console.WriteLine(Role1.Name);
            if(Role1 != null)
            {
                Console.WriteLine("You have the rights to create an asset.");
            }   
        }
        else
        {
            Console.WriteLine("You are not allowed to create an asset.");
        }

    }
    else if (UserChoice == "3")
    {
        User LoggOutUser = Context.Users.FirstOrDefault(
            x => x.Loggedin == "yes");
        LoggOutUser.Loggedin = "no";
        Context.Users.Update(LoggOutUser);
        Context.SaveChanges();
    }
    else if(UserChoice == "q")
    {
        KeepRunning = false;
    }
}

