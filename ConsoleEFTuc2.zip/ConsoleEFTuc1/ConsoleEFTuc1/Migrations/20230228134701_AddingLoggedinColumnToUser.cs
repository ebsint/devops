﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ConsoleEFTuc1.Migrations
{
    /// <inheritdoc />
    public partial class AddingLoggedinColumnToUser : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Loggedin",
                table: "Users",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Loggedin",
                table: "Users");
        }
    }
}
