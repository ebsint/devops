﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleEFTuc1
{
    internal class MyDbContext : DbContext
    {
        /*
        Users: namnet på tabellen som vi skapar.
         */
        public DbSet<User> Users { get; set; }
        public DbSet<Asset> Assets { get; set; }
        public DbSet<Role> Roles { get; set; }

        string ConnectionString = "Server=(localdb)\\mssqllocaldb;Database=consoleeftuc1;Trusted_Connection=True";
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(ConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
